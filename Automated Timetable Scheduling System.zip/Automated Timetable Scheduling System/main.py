from constraint import Problem, AllDifferentConstraint

class Course:
    def __init__(self, name, capacity, special_requirements):
        self.name = name
        self.capacity = capacity
        self.special_requirements = special_requirements
        self.timeslots = []

class Teacher:
    def __init__(self, name, available_timeslots, subjects):
        self.name = name
        self.available_timeslots = available_timeslots
        self.subjects = subjects

class Room:
    def __init__(self, name, capacity, available_timeslots, features):
        self.name = name
        self.capacity = capacity
        self.available_timeslots = available_timeslots
        self.features = features

class Timeslot:
    def __init__(self, day, time):
        self.day = day
        self.time = time

class Timetable:
    def __init__(self):
        self.schedule = {}

def backtracking_search(csp):
    assignment = {}
    return backtrack(assignment, csp)

def backtrack(assignment, csp):
    if len(assignment) == len(csp):
        return assignment

    var = select_unassigned_variable(csp, assignment)
    print(f"Trying variable: {var.name}")

    for value in order_domain_values(var, assignment, csp):
        if is_consistent(var, value, assignment, csp):
            assignment[var] = value
            print(f"Assigned {var.name} to {value.name}")
            result = backtrack(assignment, csp)
            if result is not None:
                return result
            print(f"Backtracking on {var.name}")
            del assignment[var]

    print(f"No valid assignment for {var.name}")
    return None

def select_unassigned_variable(csp, assignment):
    # Implement variable selection heuristic (MRV)
    unassigned_vars = [var for var in csp if var not in assignment]
    return mrv_heuristic(unassigned_vars, assignment, csp)

def order_domain_values(var, assignment, csp):
    # Implement value ordering heuristic (LCV)
    return lcv_heuristic(csp, var, assignment)

def is_consistent(var, value, assignment, csp):
    print(f"Checking consistency for {var.name} = {value.name}")

    if isinstance(var, Course):
        for neighbor in csp[var]:
            neighbor_value = assignment.get(neighbor)
            if neighbor_value is not None and not constraint(var, value, neighbor_value, csp):
                print(f"Inconsistent with {neighbor.name}")
                return False

    elif isinstance(var, Teacher):
        for neighbor in csp[var]:
            neighbor_value = assignment.get(neighbor)
            if neighbor_value is not None and not constraint(var, value, neighbor_value, csp):
                print(f"Inconsistent with {neighbor.name}")
                return False

    elif isinstance(var, Room):
        for neighbor in csp[var]:
            neighbor_value = assignment.get(neighbor)
            if neighbor_value is not None and not constraint(var, value, neighbor_value, csp):
                print(f"Inconsistent with {neighbor.name}")
                return False

    print("Consistent")
    return True

def constraint(var, value, neighbor_value, csp):
    # Check if the assignment satisfies the constraints
    if var in csp and neighbor_value in assignment:
        if isinstance(var, Course):
            return all([
                teacher_constraint(var, value),
                room_constraint(var, neighbor_value),
                capacity_constraint(var, neighbor_value),
                preference_constraint(value, neighbor_value)
            ])
        elif isinstance(var, Teacher):
            return teacher_constraint(neighbor_value, value)
        elif isinstance(var, Room):
            return room_constraint(neighbor_value, value)

    return True

def teacher_constraint(course, teacher):
    return course.name in teacher.subjects and not any(t in teacher.available_timeslots for t in course.timeslots)

def room_constraint(course, room):
    return not any(t in room.available_timeslots for t in course.timeslots)

def capacity_constraint(course, room):
    return course.capacity <= room.capacity

def preference_constraint(teacher, timeslot):
    return f"{timeslot.day}_{timeslot.time}" in teacher.available_timeslots

def mrv_heuristic(unassigned_vars, assignment, full_csp):
    return min(unassigned_vars, key=lambda x: len(getattr(full_csp[x], 'timeslots', [])))

def lcv_heuristic(csp, variable, assignment):
    values = sorted(csp[variable], key=lambda x: sum(len(csp[neighbor]) for neighbor in csp if x in csp[neighbor] and x not in assignment))
    return values

# Instances of classes, teachers, rooms, and timeslots
math_class = Course("Math", 30, False)
physics_class = Course("Physics", 25, True)
chemistry_class = Course("Chemistry", 20, True)
history_class = Course("History", 35, False)
computer_science_class = Course("Computer Science", 30, False)
english_class = Course("English", 25, False)
music_class = Course("Music", 20, True)
agriculture_class = Course("Agriculture", 30, False)
biology_class = Course("Biology", 25, True)

john_teacher = Teacher("John", ["Monday_10AM", "Wednesday_2PM"], ["Math", "Physics"])
jane_teacher = Teacher("Jane", ["Tuesday_1PM", "Thursday_10AM"], ["Physics"])
alice_teacher = Teacher("Alice", ["Monday_10AM", "Tuesday_1PM"], ["Chemistry"])
bob_teacher = Teacher("Bob", ["Wednesday_2PM", "Friday_3PM"], ["History"])
charlie_teacher = Teacher("Charlie", ["Monday_9AM", "Wednesday_1PM"], ["Computer Science"])
diana_teacher = Teacher("Diana", ["Tuesday_11AM", "Thursday_2PM"], ["English"])
edward_teacher = Teacher("Edward", ["Monday_3PM", "Wednesday_4PM"], ["Music", "Biology"])
fiona_teacher = Teacher("Fiona", ["Tuesday_2PM", "Thursday_3PM"], ["Agriculture", "Biology"])

classroom_a = Room("A", 40, ["Monday_10AM", "Wednesday_2PM", "Friday_3PM"], ["Projector"])
classroom_b = Room("B", 30, ["Tuesday_1PM", "Thursday_10AM", "Friday_3PM"], ["Lab"])
classroom_c = Room("C", 25, ["Monday_9AM", "Wednesday_4PM", "Friday_4PM"], ["Projector", "Lab"])
classroom_d = Room("D", 30, ["Wednesday_2PM", "Friday_3PM"], ["Lab"])
classroom_e = Room("E", 35, ["Monday_9AM", "Wednesday_1PM", "Friday_2PM"], ["Lab"])
classroom_f = Room("F", 30, ["Tuesday_11AM", "Thursday_2PM", "Friday_2PM"], ["Projector"])
classroom_g = Room("G", 25, ["Monday_3PM", "Wednesday_4PM", "Friday_4PM"], ["Projector", "Lab"])
classroom_h = Room("H", 30, ["Tuesday_2PM", "Thursday_3PM", "Friday_4PM"], ["Lab"])

morning_slot = Timeslot("Monday", "10AM")
afternoon_slot = Timeslot("Wednesday", "2PM")
evening_slot = Timeslot("Thursday", "7PM")
night_slot = Timeslot("Friday", "8PM")
morning_slot_2 = Timeslot("Thursday", "11AM")
afternoon_slot_2 = Timeslot("Friday", "2PM")
morning_slot_3 = Timeslot("Tuesday", "9AM")
afternoon_slot_3 = Timeslot("Friday", "1PM")

# Set timeslots for classes
math_class.timeslots = [morning_slot]
physics_class.timeslots = [afternoon_slot]
chemistry_class.timeslots = [evening_slot]
history_class.timeslots = [night_slot]
computer_science_class.timeslots = [morning_slot_2]
english_class.timeslots = [afternoon_slot_2]
music_class.timeslots = [morning_slot_3]
agriculture_class.timeslots = [afternoon_slot_3]
biology_class.timeslots = [morning_slot_3]

# Create a timetable instance
timetable = Timetable()

# Create CSP representation and constraints
csp = {
    math_class: [john_teacher, classroom_a],
    physics_class: [jane_teacher, classroom_b],
    chemistry_class: [alice_teacher, classroom_c],
    history_class: [bob_teacher, classroom_d],
    computer_science_class: [charlie_teacher, classroom_e],
    english_class: [diana_teacher, classroom_f],
    music_class: [edward_teacher, classroom_g],
    agriculture_class: [fiona_teacher, classroom_h],
    biology_class: [fiona_teacher, classroom_h]
}

# Run CSP algorithms with and without heuristics
result_backtracking = backtracking_search(csp)

# Evaluate and compare the results
if result_backtracking is not None:
    print("Schedule found:")
    for var, value in result_backtracking.items():
        print(f"{var.name} scheduled in {value.name}")
else:
    print("No valid schedule found.")


